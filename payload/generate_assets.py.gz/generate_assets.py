import os, math, random
from pathlib import Path
import numpy as np
from PIL import Image, ImageFilter
import trimesh

ROOT=Path(__file__).resolve().parent
MODELS=ROOT/'assets'/'models'; TEX=ROOT/'assets'/'textures'
MODELS.mkdir(parents=True, exist_ok=True); TEX.mkdir(parents=True, exist_ok=True)
random.seed(42); np.random.seed(42)

# ---------- utilities ----------
def combine(parts):
    clean=[]
    for m in parts:
        if m is None: continue
        if not isinstance(m,trimesh.Trimesh):
            m=trimesh.util.concatenate(tuple(m.geometry.values()))
        clean.append(m)
    out=trimesh.util.concatenate(clean)
    out.remove_unreferenced_vertices()
    out.fix_normals()
    return out

def tf(mesh, scale=None, translate=None, rot=None):
    m=mesh.copy()
    if scale is not None: m.apply_scale(scale)
    if rot is not None:
        axis, angle = rot
        m.apply_transform(trimesh.transformations.rotation_matrix(angle, axis))
    if translate is not None: m.apply_translation(translate)
    return m

def lathe(profile, seg=48):
    # profile list of (radius,y)
    vs=[]; fs=[]
    for i,(r,y) in enumerate(profile):
        for j in range(seg):
            a=2*math.pi*j/seg
            vs.append([r*math.cos(a),y,r*math.sin(a)])
    rows=len(profile)
    for i in range(rows-1):
        for j in range(seg):
            a=i*seg+j;b=i*seg+(j+1)%seg;c=(i+1)*seg+(j+1)%seg;d=(i+1)*seg+j
            fs += [[a,b,c],[a,c,d]]
    # caps
    vs.append([0,profile[0][1],0]); bot=len(vs)-1
    vs.append([0,profile[-1][1],0]); top=len(vs)-1
    for j in range(seg):
        fs.append([bot,(j+1)%seg,j])
        o=(rows-1)*seg
        fs.append([top,o+j,o+(j+1)%seg])
    return trimesh.Trimesh(np.array(vs),np.array(fs),process=True)

def tube_arc(radius=3, tube=0.45, angle0=0, angle1=math.pi, major_seg=36, minor_seg=10, depth=1.0):
    vs=[];fs=[]
    # semicircular arch lies in XY, tube is radial round-ish with z scale depth
    for i in range(major_seg+1):
        a=angle0+(angle1-angle0)*i/major_seg
        cx=radius*math.cos(a); cy=radius*math.sin(a)
        # normal in arch plane
        nx=math.cos(a); ny=math.sin(a)
        for j in range(minor_seg):
            b=2*math.pi*j/minor_seg
            rr=tube*math.cos(b); z=depth*tube*math.sin(b)
            vs.append([cx+nx*rr,cy+ny*rr,z])
    for i in range(major_seg):
        for j in range(minor_seg):
            a=i*minor_seg+j;b=i*minor_seg+(j+1)%minor_seg;c=(i+1)*minor_seg+(j+1)%minor_seg;d=(i+1)*minor_seg+j
            fs += [[a,b,c],[a,c,d]]
    m=trimesh.Trimesh(np.array(vs),np.array(fs),process=True);m.fix_normals();return m

def shard(length=2.5,width=.45,depth=.35):
    # irregular spear shard
    v=np.array([[-width,-length*.5,-depth],[width*.8,-length*.5,-depth*.7],[width,length*.18,-depth*.4],[0,length*.5,0],[-width*.7,length*.12,depth*.5],[width*.45,-length*.45,depth]],float)
    f=np.array([[0,1,2],[0,2,4],[0,4,5],[0,5,1],[1,5,3],[1,3,2],[2,3,4],[4,3,5]])
    return trimesh.Trimesh(v,f,process=True)

def export(name, mesh):
    p=MODELS/name
    p.write_text(trimesh.exchange.obj.export_obj(mesh,include_normals=True,include_color=False,include_texture=False), encoding='utf-8')
    print(name, len(mesh.vertices), len(mesh.faces))

# ---------- materials textures ----------
def fbm(h,w,octaves=5):
    acc=np.zeros((h,w),float); amp=1.; total=0
    for o in range(octaves):
        scale=max(2,2**(octaves-o))
        sh=max(2,h//scale); sw=max(2,w//scale)
        small=np.random.rand(sh,sw).astype('float32')
        im=Image.fromarray(np.uint8(small*255)).resize((w,h),Image.Resampling.BICUBIC).filter(ImageFilter.GaussianBlur(radius=max(0.4,scale/7)))
        n=np.asarray(im)/255.
        acc+=n*amp; total+=amp;amp*=0.5
    return acc/total

def normal_from_height(height, strength=3.0):
    gy,gx=np.gradient(height)
    nx=-gx*strength; ny=-gy*strength; nz=np.ones_like(height)
    l=np.sqrt(nx*nx+ny*ny+nz*nz); nx/=l; ny/=l; nz/=l
    rgb=np.dstack([(nx*.5+.5),(ny*.5+.5),(nz*.5+.5)])
    return np.uint8(np.clip(rgb*255,0,255))

def make_mat(prefix, base, rough_range, crack=True, rust=False):
    S=1024
    h=fbm(S,S,6)
    fine=fbm(S,S,3)
    if crack:
        # dark crack network from ridge intersections
        gx=np.abs(np.gradient(h,axis=1)); gy=np.abs(np.gradient(h,axis=0)); rid=(gx+gy)
        rid=(rid-rid.min())/(rid.max()-rid.min()+1e-6)
        cracks=(rid>np.quantile(rid,0.965)).astype(float)
        cracks=np.asarray(Image.fromarray(np.uint8(cracks*255)).filter(ImageFilter.GaussianBlur(0.8)))/255.
    else: cracks=np.zeros_like(h)
    height=np.clip(.62*h+.28*fine-.35*cracks,0,1)
    b=np.array(base,float)[None,None,:]
    col=b*(.72+.42*height[...,None])
    if rust:
        rustmask=np.clip((fbm(S,S,5)-.52)*3.2,0,1)[...,None]
        rustc=np.array([0.43,0.18,0.06])[None,None,:]
        col=col*(1-rustmask*.55)+rustc*rustmask*.55
    col*= (1-cracks[...,None]*.55)
    rough=rough_range[0]+(rough_range[1]-rough_range[0])*(1-height*.45+cracks*.4)
    Image.fromarray(np.uint8(np.clip(col,0,1)*255)).save(TEX/f'{prefix}_albedo.png', optimize=True)
    Image.fromarray(normal_from_height(height,4.2)).save(TEX/f'{prefix}_normal.png', optimize=True)
    Image.fromarray(np.uint8(np.clip(rough,0,1)*255)).save(TEX/f'{prefix}_roughness.png', optimize=True)
    Image.fromarray(np.uint8(np.clip(height,0,1)*255)).save(TEX/f'{prefix}_height.png', optimize=True)

make_mat('stone',(0.20,0.205,0.19),(0.72,0.98),True)
make_mat('bone',(0.43,0.41,0.34),(0.62,0.92),True)
make_mat('iron',(0.12,0.115,0.10),(0.50,0.88),False,True)
make_mat('ash',(0.10,0.095,0.09),(0.82,1.0),True)

# ---------- models ----------
# Hero column
profile=[(2.3,0),(2.45,.35),(2.15,.7),(1.95,1.0),(1.58,1.3),(1.48,2.0),(1.38,10.8),(1.52,11.25),(1.7,11.55),(2.02,11.9),(2.18,12.3),(2.45,12.6),(2.35,12.95)]
col=lathe(profile,64)
# fluting detail as 16 vertical ribs
ribs=[]
for i in range(16):
    a=2*math.pi*i/16
    r=1.52
    rib=trimesh.creation.box(extents=[.16,8.7,.34])
    rib.apply_translation([r*math.cos(a),6.15,r*math.sin(a)])
    rib.apply_transform(trimesh.transformations.rotation_matrix(-a,[0,1,0]))
    ribs.append(rib)
# chipped crown shards
chips=[]
for i in range(7):
    s=shard(.7+random.random()*.8,.15+.15*random.random(),.13)
    s.apply_translation([(random.random()-.5)*3.3,12.9+random.random()*.8,(random.random()-.5)*3.3]);chips.append(s)
export('column_hero.obj',combine([col,*ribs,*chips]))

# Arch module
arch=tube_arc(5.6,.65,0,math.pi,48,12,1.6)
arch.apply_translation([0,6.0,0])
legs=[tf(trimesh.creation.box([1.2,6.3,1.9]),translate=[-5.6,3,0]),tf(trimesh.creation.box([1.2,6.3,1.9]),translate=[5.6,3,0])]
keystone=tf(shard(2.2,.75,.5),scale=[1.1,1,1.5],translate=[0,11.6,0])
export('arch_monument.obj',combine([arch,*legs,keystone]))

# Broken wall slab with buttresses
parts=[tf(trimesh.creation.box([8,6,.9]),translate=[0,3,0]),tf(trimesh.creation.box([1.2,7,1.8]),translate=[-3.8,3.5,.2]),tf(trimesh.creation.box([1.2,7,1.8]),translate=[3.8,3.5,.2])]
for x in [-3,-1.5,0,1.5,3]:
    s=shard(1.0+random.random(),.4,.5); s.apply_translation([x,6.5+random.random(),0]);parts.append(s)
export('wall_ruined.obj',combine(parts))

# Altar dais
parts=[]
for i,(sx,sy,sz) in enumerate([(12,.7,9),(10,.55,7),(8,.5,5.4),(5,.4,3.6)]):
    parts.append(tf(trimesh.creation.box([sx,sy,sz]),translate=[0,i*.65,0]))
for a in np.linspace(0,2*math.pi,10,endpoint=False):
    s=shard(2.3,.35,.25); s.apply_transform(trimesh.transformations.rotation_matrix(a,[0,1,0])); s.apply_translation([4.9*math.cos(a),2.0,4.9*math.sin(a)]);parts.append(s)
export('altar_dais.obj',combine(parts))

# Brazier
parts=[lathe([(1.4,0),(1.55,.3),(1.15,.55),(.95,.9),(.72,1.05),(.38,1.35),(.34,2.6),(.7,2.85)],40)]
for i in range(4):
    a=i*math.pi/2
    arm=shard(2.0,.22,.18);arm.apply_transform(trimesh.transformations.rotation_matrix(a,[0,1,0]));arm.apply_transform(trimesh.transformations.rotation_matrix(.55,[0,0,1]));arm.apply_translation([1.0*math.cos(a),2.4,1.0*math.sin(a)]);parts.append(arm)
export('brazier.obj',combine(parts))

# Gate
parts=[]
parts += [tf(trimesh.creation.box([1.2,11,2]),translate=[-4.5,5.5,0]),tf(trimesh.creation.box([1.2,11,2]),translate=[4.5,5.5,0])]
for x in np.linspace(-3.6,3.6,9):
    bar=tf(trimesh.creation.cylinder(radius=.18,height=8,sections=12),rot=([1,0,0],math.pi/2),translate=[x,5.0,0])
    parts.append(bar); parts.append(tf(shard(1.7,.22,.18),translate=[x,9.6,0]))
parts.append(tf(trimesh.creation.box([10,1.0,2.2]),translate=[0,10.2,0]))
export('gate_ancient.obj',combine(parts))

# Rift frame: 26 irregular shards in elliptical ring
parts=[]
for i in range(26):
    a=2*math.pi*i/26
    rx,ry=5.2,8.5
    x=rx*math.cos(a); y=ry*math.sin(a)+8.6
    s=shard(2.0+random.random()*2.4,.35+random.random()*.4,.22+random.random()*.3)
    s.apply_transform(trimesh.transformations.rotation_matrix(-a+.2*(random.random()-.5),[0,0,1]))
    s.apply_transform(trimesh.transformations.rotation_matrix(.3*(random.random()-.5),[0,1,0]))
    s.apply_translation([x,y,(random.random()-.5)*.7]);parts.append(s)
export('rift_frame.obj',combine(parts))

# Floor slab irregular prism (manual triangulation, no optional polygon engine)
ang=np.linspace(0,2*math.pi,9,endpoint=False);rad=1+np.random.uniform(-.18,.22,len(ang));pts=np.c_[np.cos(ang)*rad*2.2,np.sin(ang)*rad*1.7]
vs=[];fs=[];n=len(pts);hsl=.28
for y in (-hsl/2,hsl/2):
    for x,z in pts: vs.append([x,y,z])
# top/bottom fans
for i in range(1,n-1): fs.append([0,i+1,i]); fs.append([n,n+i,n+i+1])
for i in range(n):
    j=(i+1)%n; fs += [[i,j,n+j],[i,n+j,n+i]]
slab=trimesh.Trimesh(np.array(vs),np.array(fs),process=True); slab.fix_normals()
export('floor_slab.obj',slab)

# statues helper
def capsule_between(a,b,r,sections=16):
    a=np.array(a,float);b=np.array(b,float);vec=b-a;L=np.linalg.norm(vec)
    c=trimesh.creation.capsule(height=max(.01,L-2*r),radius=r,count=[sections,sections])
    # capsule default along Z? inspect extents; align z axis to vec
    z=np.array([0,0,1.]); v=vec/L
    axis=np.cross(z,v); dot=np.dot(z,v)
    if np.linalg.norm(axis)>1e-6:
        c.apply_transform(trimesh.transformations.rotation_matrix(math.acos(np.clip(dot,-1,1)),axis))
    elif dot<0: c.apply_transform(trimesh.transformations.rotation_matrix(math.pi,[1,0,0]))
    c.apply_translation((a+b)/2);return c

def statue_unranked():
    p=[]
    # broad pedestal
    p += [tf(trimesh.creation.cylinder(radius=4.8,height=.9,sections=12),translate=[0,0,0]), tf(trimesh.creation.cylinder(radius=4.0,height=.6,sections=10),translate=[0,.7,0])]
    torso=lathe([(2.5,0),(2.8,.6),(2.2,2.0),(1.75,5.8),(2.1,7.0),(1.65,8.5)],32); torso.apply_translation([0,1.2,0]);p.append(torso)
    # cape fins
    for side in (-1,1):
        cape=shard(9.5,2.0,0.6);cape.apply_scale([1.1,1,1]);cape.apply_transform(trimesh.transformations.rotation_matrix(side*.35,[0,0,1]));cape.apply_translation([side*2.6,5.4,1.0]);p.append(cape)
    head=trimesh.creation.icosphere(subdivisions=3,radius=1.65);head.apply_scale([.92,1.1,.9]);head.apply_translation([0,11.0,0]);p.append(head)
    # no face: visor slit frame
    p.append(tf(trimesh.creation.box([2.5,.22,.35]),translate=[0,11.1,-1.45]))
    # arms downward / one hand open
    p.append(capsule_between([-1.9,8.5,-.2],[-3.0,3.7,.2],.65)); p.append(capsule_between([1.9,8.5,-.2],[3.4,5.4,-.3],.68))
    # floating broken halo/crown, intentionally huge
    for i in range(13):
        a=2*math.pi*i/13
        if i in (2,8): continue
        s=shard(3.1+random.random()*1.4,.33,.26);s.apply_transform(trimesh.transformations.rotation_matrix(-a,[0,0,1]));s.apply_translation([5.1*math.cos(a),13.2+2.0*math.sin(a),.3*math.sin(i*1.7)]);p.append(s)
    # vertical null scar
    scar=shard(6.2,.18,.16);scar.apply_translation([0,8.0,-1.7]);p.append(scar)
    return combine(p)
export('statue_unranked.obj',statue_unranked())

def statue_sacrifice():
    p=[tf(trimesh.creation.cylinder(radius=3.1,height=.7,sections=10),translate=[0,0,0])]
    # kneeling torso and legs
    torso=lathe([(1.8,0),(2.0,.5),(1.6,3.0),(1.35,5.8),(1.45,6.6)],28);torso.apply_transform(trimesh.transformations.rotation_matrix(.22,[1,0,0]));torso.apply_translation([0,1.0,0]);p.append(torso)
    head=trimesh.creation.icosphere(subdivisions=2,radius=1.25);head.apply_translation([0,8.0,.5]);p.append(head)
    p.append(capsule_between([-1.5,6.1,0],[-2.6,2.5,-1],.5));p.append(capsule_between([1.5,6.1,0],[2.3,2.0,-.8],.5))
    p.append(capsule_between([-1.0,1.8,.2],[-1.7,.7,1.8],.65));p.append(capsule_between([1.0,1.8,.2],[1.8,.7,1.5],.65))
    # sword driven into ground
    p.append(tf(trimesh.creation.box([.35,7,.18]),rot=([0,0,1],-.08),translate=[0.6,4.0,-2.1]));p.append(tf(trimesh.creation.box([2.0,.3,.4]),translate=[.88,6.9,-2.1]))
    # chain links implied by torus rings
    for i in range(7):
        t=trimesh.creation.torus(major_radius=.35,minor_radius=.08,major_sections=16,minor_sections=8);t.apply_scale([1,.7,1]);t.apply_translation([-2.2+i*.65,4.3-i*.35,-1.2]);p.append(t)
    return combine(p)
export('statue_sacrifice.obj',statue_sacrifice())

def statue_judgement():
    p=[tf(trimesh.creation.cylinder(radius=3.0,height=.7,sections=12),translate=[0,0,0])]
    torso=lathe([(1.9,0),(2.2,.6),(1.75,3.0),(1.55,6.4),(1.7,7.2)],28);torso.apply_translation([0,1,0]);p.append(torso)
    head=trimesh.creation.icosphere(subdivisions=2,radius=1.3);head.apply_scale([.9,1.05,.9]);head.apply_translation([0,9.7,0]);p.append(head)
    # blindfold
    p.append(tf(trimesh.creation.box([2.5,.35,.3]),translate=[0,9.8,-1.12]))
    # arms extended like scales
    p.append(capsule_between([-1.6,7.2,0],[-4.7,6.3,0],.48));p.append(capsule_between([1.6,7.2,0],[4.7,6.3,0],.48))
    for sx in (-1,1):
        p.append(tf(trimesh.creation.cylinder(radius=.95,height=.18,sections=20),translate=[sx*5.1,4.2,0]));
        for dx in (-.65,.65): p.append(tf(trimesh.creation.cylinder(radius=.05,height=2.0,sections=8),translate=[sx*5.1+dx,5.2,0]))
    # blade crown
    for i in range(7):
        a=-.8+i*.27;s=shard(2.8,.28,.22);s.apply_transform(trimesh.transformations.rotation_matrix(a,[0,0,1]));s.apply_translation([(i-3)*.55,12.3-abs(i-3)*.15,0]);p.append(s)
    return combine(p)
export('statue_judgement.obj',statue_judgement())

# rubble cluster
parts=[]
for i in range(26):
    s=trimesh.creation.icosphere(subdivisions=1,radius=.3+random.random()*.8);s.apply_scale([1+random.random()*1.8,.4+random.random()*.8,.7+random.random()*1.4]);s.apply_translation([(random.random()-.5)*6,random.random()*1.3,(random.random()-.5)*5]);parts.append(s)
export('rubble_cluster.obj',combine(parts))

print('assets done')

# ---------- Character / enemy silhouettes for marketing scene ----------
def hunter_model():
    p=[]
    # boots / legs
    p.append(capsule_between([-.48,.35,0],[-.42,3.2,0],.33,14)); p.append(capsule_between([.48,.35,0],[.42,3.2,0],.33,14))
    p.append(tf(trimesh.creation.box([.7,.55,1.15]),translate=[-.48,.2,-.22]));p.append(tf(trimesh.creation.box([.7,.55,1.15]),translate=[.48,.2,-.22]))
    # torso / coat
    torso=lathe([(1.05,0),(1.18,.55),(1.02,2.35),(.82,3.6),(.9,4.1)],24);torso.apply_scale([.75,1,.55]);torso.apply_translation([0,3.0,0]);p.append(torso)
    # shoulders, arms
    p.append(capsule_between([-.85,6.5,0],[-1.25,3.6,-.15],.30,12)); p.append(capsule_between([.85,6.5,0],[1.25,3.75,-.1],.30,12))
    # hood + head
    head=trimesh.creation.icosphere(subdivisions=2,radius=.68);head.apply_scale([.9,1.12,.86]);head.apply_translation([0,7.45,0]);p.append(head)
    hood=lathe([(.82,0),(.92,.35),(.78,1.1),(.28,1.65)],24);hood.apply_translation([0,6.7,.08]);p.append(hood)
    # split coat tails
    for side in (-1,1):
        s=shard(3.3,.58,.23);s.apply_transform(trimesh.transformations.rotation_matrix(side*.10,[0,0,1]));s.apply_translation([side*.42,3.1,.45]);p.append(s)
    # sword along back, not a copied franchise weapon
    p.append(tf(trimesh.creation.box([.22,4.5,.12]),rot=([0,0,1],math.radians(-23)),translate=[.9,5.0,.55]));
    blade=shard(2.6,.35,.12);blade.apply_transform(trimesh.transformations.rotation_matrix(math.radians(-23),[0,0,1]));blade.apply_translation([1.65,7.0,.55]);p.append(blade)
    return combine(p)
export('player_hunter.obj', hunter_model())

def custodian_model():
    p=[]
    # armored stone giant, broad proportions
    p.append(tf(trimesh.creation.cylinder(radius=3.4,height=.8,sections=12),translate=[0,.4,0]))
    p.append(capsule_between([-1.55,1.2,0],[-1.35,5.6,0],.78,18));p.append(capsule_between([1.55,1.2,0],[1.35,5.6,0],.78,18))
    torso=lathe([(3.0,0),(3.5,.8),(3.1,3.5),(2.65,7.6),(3.15,9.0),(2.35,10.6)],36);torso.apply_scale([1,.95,.72]);torso.apply_translation([0,4.2,0]);p.append(torso)
    # layered shoulder monuments
    for sx in (-1,1):
        p.append(tf(trimesh.creation.icosphere(subdivisions=1,radius=1.7),scale=[1.25,.68,1],translate=[sx*3.1,12.1,.1]))
        p.append(capsule_between([sx*3.0,10.8,0],[sx*4.3,5.0,.1],.78,18))
        # forearm slab
        p.append(tf(trimesh.creation.box([1.65,3.6,1.55]),rot=([0,0,1],sx*.18),translate=[sx*4.6,4.4,0]))
    head=trimesh.creation.icosphere(subdivisions=2,radius=1.65);head.apply_scale([1.12,1.15,.9]);head.apply_translation([0,15.4,0]);p.append(head)
    # faceless liturgy mask
    p.append(tf(trimesh.creation.box([2.7,.24,.38]),translate=[0,15.5,-1.48]))
    # back reliquary crown / vertical slabs
    for i in range(7):
        x=(i-3)*.9;h=3.5-abs(i-3)*.35
        s=shard(h,.42,.30);s.apply_translation([x,17.3+abs(i-3)*.15,1.1]);p.append(s)
    # hammer-staff
    p.append(tf(trimesh.creation.cylinder(radius=.28,height=11,sections=12),rot=([1,0,0],math.pi/2),translate=[5.2,8.0,0]))
    p.append(tf(trimesh.creation.box([2.8,2.2,1.8]),rot=([0,0,1],.15),translate=[5.4,13.2,0]))
    # broken ritual plates on hips
    for sx in (-1,1):
        plate=shard(4.0,.9,.35);plate.apply_transform(trimesh.transformations.rotation_matrix(sx*.25,[0,0,1]));plate.apply_translation([sx*2.7,6.2,.5]);p.append(plate)
    return combine(p)
export('boss_custodian.obj',custodian_model())

def ash_bailiff_model():
    p=[]
    # leaner executioner silhouette
    p.append(capsule_between([-.65,.5,0],[-.55,4.0,0],.46,14));p.append(capsule_between([.65,.5,0],[.55,4.0,0],.46,14))
    torso=lathe([(1.65,0),(1.9,.55),(1.55,3.0),(1.32,6.3),(1.55,7.4)],30);torso.apply_scale([.9,1,.65]);torso.apply_translation([0,3.8,0]);p.append(torso)
    for sx in (-1,1):
        p.append(capsule_between([sx*1.45,9.5,0],[sx*2.2,5.3,-.1],.44,14))
        shoulder=shard(2.7,.75,.35);shoulder.apply_transform(trimesh.transformations.rotation_matrix(sx*.8,[0,0,1]));shoulder.apply_translation([sx*1.75,10.0,.1]);p.append(shoulder)
    head=trimesh.creation.icosphere(subdivisions=2,radius=1.0);head.apply_scale([.82,1.12,.82]);head.apply_translation([0,11.7,0]);p.append(head)
    # execution hood blade crest
    for i in range(5):
        s=shard(2.4-i*.18,.25,.18);s.apply_transform(trimesh.transformations.rotation_matrix((i-2)*.13,[0,0,1]));s.apply_translation([(i-2)*.38,13.1-abs(i-2)*.12,.15]);p.append(s)
    # huge cleaver with asymmetry
    handle=tf(trimesh.creation.cylinder(radius=.18,height=7.5,sections=10),rot=([1,0,0],math.pi/2),translate=[2.8,7.8,0]);p.append(handle)
    blade=shard(5.6,1.5,.32);blade.apply_scale([1.2,1,1]);blade.apply_transform(trimesh.transformations.rotation_matrix(-.28,[0,0,1]));blade.apply_translation([4.0,11.1,0]);p.append(blade)
    # coat tails
    for sx in (-1,0,1):
        s=shard(4.0,1.0,.24);s.apply_transform(trimesh.transformations.rotation_matrix(sx*.15,[0,0,1]));s.apply_translation([sx*.7,4.1,.5]);p.append(s)
    return combine(p)
export('enemy_ash_bailiff.obj',ash_bailiff_model())

# ---------- Additional architectural kit V2.1 ----------
def broken_stairs():
    parts=[]
    for i in range(11):
        if i in (4,8):
            # partial broken step
            parts.append(tf(trimesh.creation.box([3.4,.42,1.0]),translate=[-1.2,i*.42,i*.92]))
            rubble=shard(1.1,.38,.3);rubble.apply_transform(trimesh.transformations.rotation_matrix(.35,[0,0,1]));rubble.apply_translation([1.8,i*.42+.1,i*.92]);parts.append(rubble)
        else:
            w=7.4-(i*.08)
            parts.append(tf(trimesh.creation.box([w,.42,1.05]),translate=[0,i*.42,i*.92]))
    # side fractured cheeks
    for sx in (-1,1):
        for i in (2,6,10):
            s=shard(1.8,.45,.34);s.apply_transform(trimesh.transformations.rotation_matrix(sx*.38,[0,0,1]));s.apply_translation([sx*3.8,i*.42+.3,i*.92]);parts.append(s)
    return combine(parts)
export('stair_broken.obj',broken_stairs())

def balcony_module():
    parts=[tf(trimesh.creation.box([10,.65,4.6]),translate=[0,0,0])]
    # underside corbels
    for x in (-4,-2,0,2,4):
        s=shard(3.0,.55,.55);s.apply_transform(trimesh.transformations.rotation_matrix(math.pi,[1,0,0]));s.apply_translation([x,-1.6,1.5]);parts.append(s)
    # parapet, broken in middle
    for x in (-4.2,-2.8,2.8,4.2):
        parts.append(tf(trimesh.creation.box([1.1,1.3,.55]),translate=[x,1.0,-2.1]))
    for x in (-4.6,4.6):
        parts.append(tf(trimesh.creation.box([.65,2.4,4.6]),translate=[x,1.2,0]))
    return combine(parts)
export('balcony.obj',balcony_module())

def bridge_ruined():
    parts=[]
    # segmented deck with subtle vertical variation and missing corners
    for i in range(10):
        z=(i-4.5)*2.1
        w=5.6 if i not in (3,7) else 4.1
        x=-.7 if i==3 else (.7 if i==7 else 0)
        parts.append(tf(trimesh.creation.box([w,.55,1.95]),translate=[x,.05*math.sin(i),z]))
    # broken side rails
    for sx in (-1,1):
        for i in range(0,10,2):
            if (sx==1 and i==6) or (sx==-1 and i==2): continue
            parts.append(tf(trimesh.creation.box([.45,1.4,1.4]),translate=[sx*2.55,1.0,(i-4.5)*2.1]))
    return combine(parts)
export('bridge_ruined.obj',bridge_ruined())

def annulus(r0,r1,y,seg=64):
    vs=[];fs=[]
    for i in range(seg):
        a=2*math.pi*i/seg
        for r in (r0,r1): vs.append([r*math.cos(a),y,r*math.sin(a)])
    for i in range(seg):
        j=(i+1)%seg;a=i*2;b=i*2+1;c=j*2+1;d=j*2
        fs += [[a,b,c],[a,c,d]]
    return trimesh.Trimesh(np.array(vs),np.array(fs),process=True)

def boss_arena():
    parts=[]
    # concentric stone rings at stepped heights
    parts.append(annulus(0,12.5,0,72))
    ring=annulus(12.5,15.4,-.35,72);parts.append(ring)
    ring2=annulus(15.4,18.4,-.7,72);parts.append(ring2)
    # radial monolith sockets and cracked chunks
    for i in range(16):
        a=2*math.pi*i/16
        if i in (3,9,14):
            s=shard(2.4,.7,.55);s.apply_transform(trimesh.transformations.rotation_matrix(-a,[0,1,0]));s.apply_translation([16.8*math.cos(a),-.15,16.8*math.sin(a)]);parts.append(s)
        else:
            parts.append(tf(trimesh.creation.box([1.4,1.1,3.2]),rot=([0,1,0],-a),translate=[16.8*math.cos(a),-.45,16.8*math.sin(a)]))
    return combine(parts)
export('boss_arena.obj',boss_arena())

def arena_obelisk():
    parts=[]
    base=lathe([(1.4,0),(1.6,.4),(1.2,.8),(.85,1.1),(.72,5.8),(.35,7.3),(0,8.2)],20);parts.append(base)
    for i in range(4):
        a=i*math.pi/2;s=shard(2.7,.32,.24);s.apply_transform(trimesh.transformations.rotation_matrix(a,[0,1,0]));s.apply_translation([1.0*math.cos(a),5.2,1.0*math.sin(a)]);parts.append(s)
    return combine(parts)
export('arena_obelisk.obj',arena_obelisk())
