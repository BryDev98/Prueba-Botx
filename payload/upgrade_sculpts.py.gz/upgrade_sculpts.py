from pathlib import Path
import math, shutil
import numpy as np
import trimesh
from skimage import measure

ROOT=Path(__file__).resolve().parent/'assets'/'models'

# preserve low-poly LODs once
for n in ['statue_unranked','boss_custodian']:
    src=ROOT/f'{n}.obj'; lod=ROOT/f'{n}_lod.obj'
    if src.exists() and not lod.exists(): shutil.copy2(src,lod)
    glb=ROOT/f'{n}.glb'; lodg=ROOT/f'{n}_lod.glb'
    if glb.exists() and not lodg.exists(): shutil.copy2(glb,lodg)

def ellipsoid(X,Y,Z,c,s):
    cx,cy,cz=c; sx,sy,sz=s
    return np.sqrt(((X-cx)/sx)**2+((Y-cy)/sy)**2+((Z-cz)/sz)**2)-1.0

def capsule(X,Y,Z,a,b,r):
    a=np.array(a,float); b=np.array(b,float)
    vx=b-a
    px=X-a[0]; py=Y-a[1]; pz=Z-a[2]
    vv=np.dot(vx,vx)
    t=np.clip((px*vx[0]+py*vx[1]+pz*vx[2])/vv,0,1)
    qx=px-t*vx[0]; qy=py-t*vx[1]; qz=pz-t*vx[2]
    return np.sqrt(qx*qx+qy*qy+qz*qz)-r

def box_sdf(X,Y,Z,c,b):
    qx=np.abs(X-c[0])-b[0]; qy=np.abs(Y-c[1])-b[1]; qz=np.abs(Z-c[2])-b[2]
    ox=np.maximum(qx,0); oy=np.maximum(qy,0); oz=np.maximum(qz,0)
    outside=np.sqrt(ox*ox+oy*oy+oz*oz)
    inside=np.minimum(np.maximum.reduce([qx,qy,qz]),0)
    return outside+inside

def sculpt(bounds,res,fields):
    (xmin,xmax),(ymin,ymax),(zmin,zmax)=bounds
    nx,ny,nz=res
    xs=np.linspace(xmin,xmax,nx,dtype=np.float32);ys=np.linspace(ymin,ymax,ny,dtype=np.float32);zs=np.linspace(zmin,zmax,nz,dtype=np.float32)
    X,Y,Z=np.meshgrid(xs,ys,zs,indexing='ij')
    sdf=np.full((nx,ny,nz),99,dtype=np.float32)
    for f in fields:
        kind=f[0]
        if kind=='e': d=ellipsoid(X,Y,Z,f[1],f[2])
        elif kind=='c': d=capsule(X,Y,Z,f[1],f[2],f[3])
        elif kind=='b': d=box_sdf(X,Y,Z,f[1],f[2])
        elif kind=='subbox':
            d=box_sdf(X,Y,Z,f[1],f[2]); sdf=np.maximum(sdf,-d); continue
        sdf=np.minimum(sdf,d)
    spacing=((xmax-xmin)/(nx-1),(ymax-ymin)/(ny-1),(zmax-zmin)/(nz-1))
    verts,faces,normals,_=measure.marching_cubes(sdf,level=0,spacing=spacing,allow_degenerate=False)
    verts[:,0]+=xmin;verts[:,1]+=ymin;verts[:,2]+=zmin
    m=trimesh.Trimesh(vertices=verts,faces=faces,vertex_normals=normals,process=True)
    m.remove_unreferenced_vertices();m.fix_normals();return m

def shard(length=2.5,width=.45,depth=.35):
    v=np.array([[-width,-length*.5,-depth],[width*.8,-length*.5,-depth*.7],[width,length*.18,-depth*.4],[0,length*.5,0],[-width*.7,length*.12,depth*.5],[width*.45,-length*.45,depth]],float)
    f=np.array([[0,1,2],[0,2,4],[0,4,5],[0,5,1],[1,5,3],[1,3,2],[2,3,4],[4,3,5]])
    return trimesh.Trimesh(v,f,process=True)

def combine(parts):
    m=trimesh.util.concatenate(parts);m.remove_unreferenced_vertices();m.fix_normals();return m

def tf(m,scale=None,translate=None,rot=None):
    m=m.copy()
    if scale is not None:m.apply_scale(scale)
    if rot is not None:m.apply_transform(trimesh.transformations.rotation_matrix(rot[1],rot[0]))
    if translate is not None:m.apply_translation(translate)
    return m

def save(name,m):
    (ROOT/f'{name}.obj').write_text(trimesh.exchange.obj.export_obj(m,include_normals=True,include_texture=False),encoding='utf8')
    (ROOT/f'{name}.glb').write_bytes(trimesh.exchange.gltf.export_glb(m))
    print(name, len(m.vertices),'verts',len(m.faces),'tris', round((ROOT/f'{name}.obj').stat().st_size/1024,1),'KB')

# SIN RANGO: continuous figure, deliberately monumental and asymmetric
fields=[
 ('e',(0,5.4,0),(2.25,4.8,1.7)),        # robe/torso mass
 ('e',(0,9.0,0),(2.0,2.8,1.55)),        # chest
 ('e',(0,12.5,0),(1.35,1.55,1.18)),     # head
 ('c',(-1.7,9.4,0),(-3.0,4.2,.1),.72),
 ('c',(1.7,9.5,0),(3.6,5.8,-.2),.78),
 ('c',(-.85,2.5,.1),(-1.1,.2,.15),.85),
 ('c',(.85,2.5,.1),(1.1,.2,.15),.85),
 ('e',(-1.8,8.8,.45),(1.65,3.3,.9)),     # cape/shoulder volume
 ('e',(1.8,8.5,.5),(1.9,3.6,.95)),
]
body=sculpt(((-5.5,5.5),(-1,15),(-3.2,3.2)),(82,118,62),fields)
parts=[body]
# pedestal rings
parts += [tf(trimesh.creation.cylinder(radius=4.8,height=.85,sections=36),translate=[0,-.35,0]),tf(trimesh.creation.cylinder(radius=4.0,height=.45,sections=32),translate=[0,.25,0])]
# faceless visor slit and sternum null scar are separate hard-surface pieces
parts.append(tf(trimesh.creation.box([2.45,.18,.28]),translate=[0,12.55,-1.15]))
scar=shard(6.6,.16,.13);scar.apply_translation([0,8.1,-1.66]);parts.append(scar)
# giant broken elliptical halo
for i in range(19):
    if i in (3,4,11): continue
    a=2*math.pi*i/19
    s=shard(2.6+.55*math.sin(i*1.7)**2,.26+.07*(i%3),.22)
    s.apply_transform(trimesh.transformations.rotation_matrix(-a,[0,0,1]))
    s.apply_transform(trimesh.transformations.rotation_matrix(.12*math.sin(i),[0,1,0]))
    s.apply_translation([5.0*math.cos(a),14.7+2.15*math.sin(a),.35*math.sin(i*1.3)])
    parts.append(s)
# asymmetric mantle spines
for sx in (-1,1):
    for j in range(3):
        s=shard(3.4-j*.45,.42,.28);s.apply_transform(trimesh.transformations.rotation_matrix(sx*(.42+j*.18),[0,0,1]));s.apply_translation([sx*(2.5+j*.55),10.0-j*.55,.55]);parts.append(s)
unranked=combine(parts)
save('statue_unranked',unranked)

# THE REDACTED CUSTODIAN: connected muscular/stone mass under hard armor
fields=[
 ('c',(-1.45,.6,0),(-1.25,5.1,0),.82),('c', (1.45,.6,0),(1.25,5.1,0),.82),
 ('e',(0,8.2,0),(3.4,5.3,2.15)),('e',(0,11.8,0),(3.0,2.4,2.0)),
 ('e',(0,15.0,0),(1.65,1.8,1.45)),
 ('c',(-2.6,11.5,0),(-4.45,5.1,.05),.9),('c',(2.6,11.5,0),(4.45,5.1,.05),.9),
 ('e',(-3.15,12.0,.1),(2.0,1.35,1.55)),('e',(3.15,12.0,.1),(2.0,1.35,1.55)),
]
body=sculpt(((-6,6),(-1,17.5),(-3.4,3.4)),(86,126,64),fields)
parts=[body,tf(trimesh.creation.cylinder(radius=3.5,height=.75,sections=32),translate=[0,-.35,0])]
# hard armor breastplate
parts.append(tf(trimesh.creation.icosphere(subdivisions=2,radius=2.6),scale=[1.15,1.1,.42],translate=[0,10.4,-1.65]))
# mask slit
parts.append(tf(trimesh.creation.box([2.6,.20,.32]),translate=[0,15.0,-1.38]))
# monumental back reliquary
for i in range(9):
    x=(i-4)*.82; h=4.1-abs(i-4)*.34
    s=shard(h,.38,.28);s.apply_translation([x,17.0+abs(i-4)*.12,1.15]);parts.append(s)
# forearm armor blocks and hammer
for sx in (-1,1):
    parts.append(tf(trimesh.creation.box([1.75,3.6,1.7]),rot=([0,0,1],sx*.17),translate=[sx*4.5,5.0,0]))
    plate=shard(4.4,1.0,.38);plate.apply_transform(trimesh.transformations.rotation_matrix(sx*.23,[0,0,1]));plate.apply_translation([sx*2.7,7.2,.65]);parts.append(plate)
parts.append(tf(trimesh.creation.cylinder(radius=.30,height=11.5,sections=14),rot=([1,0,0],math.pi/2),translate=[5.25,8.0,0]))
parts.append(tf(trimesh.creation.box([3.2,2.35,2.0]),rot=([0,0,1],.14),translate=[5.5,13.35,0]))
cust=combine(parts)
save('boss_custodian',cust)
