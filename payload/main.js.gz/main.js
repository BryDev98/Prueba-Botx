(() => {
'use strict';

const canvas = document.getElementById('world');
const gl = canvas.getContext('webgl2', { antialias:true, alpha:false, powerPreference:'high-performance' });
if (!gl) { document.body.classList.add('no-webgl'); return; }
const DPR = Math.min(window.devicePixelRatio || 1, innerWidth < 760 ? 1.15 : 1.65);
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const lerp=(a,b,t)=>a+(b-a)*t;
const smooth=t=>t*t*(3-2*t);
const vadd=(a,b)=>[a[0]+b[0],a[1]+b[1],a[2]+b[2]];
const vsub=(a,b)=>[a[0]-b[0],a[1]-b[1],a[2]-b[2]];
const vmul=(a,s)=>[a[0]*s,a[1]*s,a[2]*s];
const vlen=a=>Math.hypot(a[0],a[1],a[2]);
const vnorm=a=>{const l=vlen(a)||1;return[a[0]/l,a[1]/l,a[2]/l]};
const vcross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const vdot=(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
const deg=d=>d*Math.PI/180;

const M4={
  identity:()=>new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]),
  mul:(a,b)=>{const o=new Float32Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++)o[c*4+r]=a[r]*b[c*4]+a[4+r]*b[c*4+1]+a[8+r]*b[c*4+2]+a[12+r]*b[c*4+3];return o},
  perspective:(fov,asp,n,f)=>{const q=1/Math.tan(fov/2),nf=1/(n-f);return new Float32Array([q/asp,0,0,0,0,q,0,0,0,0,(f+n)*nf,-1,0,0,2*f*n*nf,0])},
  lookAt:(eye,target,up=[0,1,0])=>{const z=vnorm(vsub(eye,target)),x=vnorm(vcross(up,z)),y=vcross(z,x);return new Float32Array([x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-vdot(x,eye),-vdot(y,eye),-vdot(z,eye),1])},
  trs:(p,r,s)=>{const [x,y,z]=r,cx=Math.cos(x),sx=Math.sin(x),cy=Math.cos(y),sy=Math.sin(y),cz=Math.cos(z),sz=Math.sin(z);const Rx=new Float32Array([1,0,0,0,0,cx,sx,0,0,-sx,cx,0,0,0,0,1]);const Ry=new Float32Array([cy,0,-sy,0,0,1,0,0,sy,0,cy,0,0,0,0,1]);const Rz=new Float32Array([cz,sz,0,0,-sz,cz,0,0,0,0,1,0,0,0,0,1]);const S=new Float32Array([s[0],0,0,0,0,s[1],0,0,0,0,s[2],0,0,0,0,1]);let m=M4.mul(M4.mul(Ry,Rx),Rz);m=M4.mul(m,S);m[12]=p[0];m[13]=p[1];m[14]=p[2];return m}
};

function compile(type,src){const s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))console.error(gl.getShaderInfoLog(s));return s}
function program(vs,fs){const p=gl.createProgram();gl.attachShader(p,compile(gl.VERTEX_SHADER,vs));gl.attachShader(p,compile(gl.FRAGMENT_SHADER,fs));gl.linkProgram(p);if(!gl.getProgramParameter(p,gl.LINK_STATUS))console.error(gl.getProgramInfoLog(p));return p}

const VS=`#version 300 es
precision highp float;
layout(location=0) in vec3 aPos;layout(location=1) in vec3 aNor;
uniform mat4 uModel,uView,uProj;out vec3 vPos;out vec3 vNor;
void main(){vec4 wp=uModel*vec4(aPos,1.0);vPos=wp.xyz;vNor=normalize(transpose(inverse(mat3(uModel)))*aNor);gl_Position=uProj*uView*wp;}`;
const FS=`#version 300 es
precision highp float;
in vec3 vPos;in vec3 vNor;out vec4 outColor;
uniform sampler2D uAlb,uNorm,uRough;uniform vec3 uTint,uCamera,uRiftColor;uniform float uScale,uEmission,uTime,uFogStart,uFogEnd,uMetal;
vec3 triWeights(vec3 n){vec3 w=pow(abs(n),vec3(6.0));return w/(w.x+w.y+w.z+0.0001);}
vec4 triSample(sampler2D t,vec3 p,vec3 n,float s){vec3 w=triWeights(n);vec4 x=texture(t,p.zy*s);vec4 y=texture(t,p.xz*s);vec4 z=texture(t,p.xy*s);return x*w.x+y*w.y+z*w.z;}
vec3 triNormal(vec3 p,vec3 n,float s){vec3 w=triWeights(n);vec3 nx=texture(uNorm,p.zy*s).xyz*2.0-1.0;vec3 ny=texture(uNorm,p.xz*s).xyz*2.0-1.0;vec3 nz=texture(uNorm,p.xy*s).xyz*2.0-1.0;vec3 wx=normalize(vec3(nx.z,nx.y,nx.x*sign(n.x)));vec3 wy=normalize(vec3(ny.x,ny.z,ny.y*sign(n.y)));vec3 wz=normalize(vec3(nz.x,nz.y,nz.z*sign(n.z)));return normalize(wx*w.x+wy*w.y+wz*w.z+n*1.45);}
void main(){
 vec3 Ng=normalize(vNor);vec3 N=triNormal(vPos,Ng,uScale);vec3 alb=pow(triSample(uAlb,vPos,Ng,uScale).rgb,vec3(2.2))*uTint;float rough=triSample(uRough,vPos,Ng,uScale).r;
 vec3 V=normalize(uCamera-vPos);vec3 key=normalize(vec3(-.42,.86,.28));vec3 fill=normalize(vec3(.56,.2,-.8));
 float nd=max(dot(N,key),0.0);float nd2=max(dot(N,fill),0.0);vec3 H=normalize(key+V);float spec=pow(max(dot(N,H),0.0),mix(52.0,8.0,rough))*(1.0-rough*.8);
 vec3 base=alb*(.08+nd*.82+nd2*.16);
 vec3 riftPos=vec3(0.0,8.0,-56.0);float rd=max(0.0,1.0-distance(vPos,riftPos)/34.0);base+=uRiftColor*rd*rd*(.5+.5*max(dot(N,normalize(riftPos-vPos)),0.0));
 float warm=0.0;vec3 bp[4];bp[0]=vec3(-7.,2.,-26.);bp[1]=vec3(7.,2.,-8.);bp[2]=vec3(-7.,2.,18.);bp[3]=vec3(7.,2.,42.);for(int i=0;i<4;i++){float q=max(0.0,1.0-distance(vPos,bp[i])/18.0);warm+=q*q*max(dot(N,normalize(bp[i]-vPos)),0.0);}base+=vec3(.75,.22,.055)*warm*.62;
 float fres=pow(1.0-max(dot(N,V),0.0),3.0);base+=vec3(.08,.07,.12)*fres;base+=mix(vec3(.04),alb,uMetal)*spec*.55;base+=alb*uEmission*(1.55+.32*sin(uTime*2.4+vPos.y*.7));
 float d=distance(uCamera,vPos);float fog=clamp((d-uFogStart)/(uFogEnd-uFogStart),0.0,1.0);vec3 fogc=vec3(.016,.017,.024);base=mix(base,fogc,fog);
 outColor=vec4(pow(base,vec3(1.0/2.2)),1.0);
}`;
const mainProg=program(VS,FS);
const loc={
 model:gl.getUniformLocation(mainProg,'uModel'),view:gl.getUniformLocation(mainProg,'uView'),proj:gl.getUniformLocation(mainProg,'uProj'),
 alb:gl.getUniformLocation(mainProg,'uAlb'),norm:gl.getUniformLocation(mainProg,'uNorm'),rough:gl.getUniformLocation(mainProg,'uRough'),tint:gl.getUniformLocation(mainProg,'uTint'),cam:gl.getUniformLocation(mainProg,'uCamera'),scale:gl.getUniformLocation(mainProg,'uScale'),em:gl.getUniformLocation(mainProg,'uEmission'),time:gl.getUniformLocation(mainProg,'uTime'),fog0:gl.getUniformLocation(mainProg,'uFogStart'),fog1:gl.getUniformLocation(mainProg,'uFogEnd'),metal:gl.getUniformLocation(mainProg,'uMetal'),rift:gl.getUniformLocation(mainProg,'uRiftColor')
};

const GVS=`#version 300 es
precision highp float;layout(location=0) in vec3 aPos;uniform mat4 uModel,uView,uProj;uniform float uTime;out float vA;void main(){vec3 lp=aPos;lp.x+=sin(uTime*2.1+lp.y*2.7)*.08;vec4 wp=uModel*vec4(lp,1.);gl_Position=uProj*uView*wp;float d=length(lp.xy);vA=1.0-smoothstep(.55,1.35,d);}`;
const GFS=`#version 300 es
precision highp float;in float vA;out vec4 outColor;uniform float uTime;uniform vec3 uGlowColor;void main(){vec3 c=mix(uGlowColor*.45,uGlowColor*1.8,.5+.5*sin(uTime*2.2));outColor=vec4(c,.11+.22*vA);}`;
const glowProg=program(GVS,GFS);const gloc={model:gl.getUniformLocation(glowProg,'uModel'),view:gl.getUniformLocation(glowProg,'uView'),proj:gl.getUniformLocation(glowProg,'uProj'),time:gl.getUniformLocation(glowProg,'uTime'),color:gl.getUniformLocation(glowProg,'uGlowColor')};

const PVS=`#version 300 es
precision highp float;layout(location=0) in vec3 aPos;uniform mat4 uView,uProj;uniform float uTime;out float life;void main(){vec3 p=aPos;p.y+=mod(uTime*.42+aPos.x*2.7+aPos.z*1.9,10.);p.x+=sin(uTime*.4+aPos.y)*.32;life=fract((p.y+20.)*.09);gl_Position=uProj*uView*vec4(p,1.);gl_PointSize=1.2+life*3.2;}`;
const PFS=`#version 300 es
precision highp float;in float life;out vec4 outColor;void main(){vec2 q=gl_PointCoord-.5;if(dot(q,q)>.25)discard;outColor=vec4(mix(vec3(.24,.21,.34),vec3(.76,.70,.96),life),.12+.45*life);}`;
const partProg=program(PVS,PFS),ploc={view:gl.getUniformLocation(partProg,'uView'),proj:gl.getUniformLocation(partProg,'uProj'),time:gl.getUniformLocation(partProg,'uTime')};

function createMesh(vertices,normals){
 const vao=gl.createVertexArray();gl.bindVertexArray(vao);
 const vb=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,vb);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(vertices),gl.STATIC_DRAW);gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,3,gl.FLOAT,false,0,0);
 const nb=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,nb);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(normals),gl.STATIC_DRAW);gl.enableVertexAttribArray(1);gl.vertexAttribPointer(1,3,gl.FLOAT,false,0,0);
 gl.bindVertexArray(null);return{vao,count:vertices.length/3};
}
function parseOBJ(text){
 const pos=[[0,0,0]],nor=[[0,1,0]],outP=[],outN=[];
 const lines=text.split(/\r?\n/);
 for(const line of lines){const t=line.trim();if(!t||t[0]==='#')continue;const p=t.split(/\s+/);if(p[0]==='v')pos.push([+p[1],+p[2],+p[3]]);else if(p[0]==='vn')nor.push([+p[1],+p[2],+p[3]]);else if(p[0]==='f'){
   const verts=p.slice(1).map(x=>{const q=x.split('/');return{v:parseInt(q[0]),n:q[2]?parseInt(q[2]):0}});
   for(let k=1;k<verts.length-1;k++){const tri=[verts[0],verts[k],verts[k+1]];let faceN=null;if(!tri[0].n||!tri[1].n||!tri[2].n){const A=pos[tri[0].v],B=pos[tri[1].v],C=pos[tri[2].v];faceN=vnorm(vcross(vsub(B,A),vsub(C,A)));}for(const q of tri){outP.push(...pos[q.v]);outN.push(...(q.n?nor[q.n]:faceN));}}
 }}
 return createMesh(outP,outN);
}
async function loadOBJ(url){const r=await fetch(url);if(!r.ok)throw new Error(url);return parseOBJ(await r.text());}
function texSolid(rgb){const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array([...rgb,255]));return t}
function loadTex(url,fallback){return new Promise(resolve=>{const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array([...fallback,255]));const im=new Image();im.onload=()=>{gl.bindTexture(gl.TEXTURE_2D,t);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,im);gl.generateMipmap(gl.TEXTURE_2D);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.REPEAT);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.REPEAT);resolve(t)};im.onerror=()=>resolve(t);im.src=url})}

const assets={};const mats={};const objects=[];let glowMesh=null;
function add(meshKey,p,s=[1,1,1],mat='stone',r=[0,0,0],em=0,tint=[1,1,1]){objects.push({meshKey,p,s,mat,r,em,tint,model:M4.trs(p,r,s)})}
function addGlowPlane(){
 const p=[-1,-1,0,1,-1,0,1,1,0,-1,-1,0,1,1,0,-1,1,0],n=new Array(18).fill(0);glowMesh=createMesh(p,n);
}
function makeParticleVAO(){const count=1250,pp=[];let seed=9321;const rnd=()=>((seed=(seed*16807)%2147483647)-1)/2147483646;for(let i=0;i<count;i++)pp.push((rnd()-.5)*52,-13+rnd()*34,-74+rnd()*174);const vao=gl.createVertexArray();gl.bindVertexArray(vao);const b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(pp),gl.STATIC_DRAW);gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,3,gl.FLOAT,false,0,0);gl.bindVertexArray(null);return{vao,count}}
const particles=makeParticleVAO();

async function loadAll(){
 const bootStatus=document.querySelector('.boot__status');
 const modelNames=['column_hero','arch_monument','wall_ruined','altar_dais','brazier','gate_ancient','rift_frame','floor_slab','statue_unranked','statue_sacrifice','statue_judgement','rubble_cluster','player_hunter','boss_custodian','enemy_ash_bailiff','stair_broken','balcony','bridge_ruined','boss_arena','arena_obelisk'];
 let done=0,total=modelNames.length+12;
 const tick=(name)=>{done++;bootStatus.textContent=`Cargando ${name} // ${Math.round(done/total*100)}%`;document.querySelector('.boot__bar span').style.width=`${Math.round(done/total*100)}%`};
 const lowDetail=innerWidth<820||((navigator.deviceMemory||8)<=4);
 for(const n of modelNames){const useLOD=lowDetail&&(n==='statue_unranked'||n==='boss_custodian');const file=useLOD?`${n}_lod`:n;assets[n]=await loadOBJ(`assets/models/${file}.obj`);tick((useLOD?file:n).toUpperCase())}
 const defs={
  stone:{base:[84,84,76],files:'stone',scale:.085,metal:0},bone:{base:[118,111,92],files:'bone',scale:.11,metal:0},iron:{base:[40,37,33],files:'iron',scale:.16,metal:.72},ash:{base:[35,33,31],files:'ash',scale:.12,metal:0}
 };
 for(const [k,d] of Object.entries(defs)){
   const alb=await loadTex(`assets/textures/${d.files}_albedo.png`,d.base);tick(k+' ALBEDO');
   const nor=await loadTex(`assets/textures/${d.files}_normal.png`,[128,128,255]);tick(k+' NORMAL');
   const rough=await loadTex(`assets/textures/${d.files}_roughness.png`,[210,210,210]);tick(k+' ROUGHNESS');
   mats[k]={alb,nor,rough,scale:d.scale,metal:d.metal};
 }
 addGlowPlane();buildScene();
}

function buildScene(){
 // floor: irregular reusable mesh, many individual transforms for silhouette variation
 for(let z=-66;z<88;z+=3.3){for(let x=-14;x<=14;x+=4.4){const j=(Math.sin(x*1.7+z*.63)+1)*.14;add('floor_slab',[x+(Math.sin(z*.8+x)*.35),-1.8+j,z],[1.05,.55,1.05],'stone',[0,(x+z)*.045,0],0,[.82,.84,.8])}}
 // side ruin walls
 for(const side of [-1,1]){for(let z=-58;z<62;z+=16)add('wall_ruined',[side*20,1.6,z],[1.25,1.35,1.2],'stone',[0,side<0?deg(90):deg(-90),0]);}
 // colonnade + alternating arches
 for(const side of [-1,1])for(let z=-54;z<=58;z+=14){add('column_hero',[side*13.8,-1.35,z],[1,1.42,1],'stone',[0,0,0],0,[.9,.9,.85]);if((Math.round((z+54)/14)%2)===0)add('arch_monument',[0,9.2,z],[1.13,1.18,1.12],'stone',[0,0,0],0,[.82,.83,.8]);}
 // arena threshold, gate, altar and hero statue
 add('gate_ancient',[0,-1.2,44],[1.25,1.25,1.25],'iron',[0,0,0],0,[.8,.76,.7]);
 add('altar_dais',[0,-1.4,64],[1.25,1.15,1.25],'stone');
 add('statue_unranked',[0,-.8,64],[1.42,1.42,1.42],'bone',[0,deg(180),0],.035,[1.08,1.08,1.02]);
 add('statue_sacrifice',[-10.2,-1.1,35],[.96,.96,.96],'bone',[0,deg(12),0],0,[.82,.80,.72]);
 add('statue_judgement',[10.5,-1.1,35],[.92,.92,.92],'stone',[0,deg(-10),0],0,[.88,.88,.84]);
 // rift entrance
 add('rift_frame',[0,-1.2,-58],[1.15,1.15,1.15],'stone',[0,0,0],.015,[.8,.82,.82]);
 // braziers
 for(const side of [-1,1])for(const z of [-30,-4,22,48])add('brazier',[side*7,-1.4,z],[.9,.9,.9],'iron');
 // rubble clusters
 for(const side of [-1,1])for(const z of [-46,-16,12,40,72])add('rubble_cluster',[side*(10+Math.sin(z)*2),-1.6,z],[.65,.65,.65],'stone',[0,z*.17,0],0,[.78,.78,.74]);
 // scale reference: the player is intentionally tiny inside Brecha Cero
 add('player_hunter',[0,-1.35,18],[.50,.50,.50],'ash',[0,deg(180),0],0,[.55,.58,.62]);
 // traversal architecture: broken stairs, elevated balconies and a ruined bridge
 add('stair_broken',[0,-1.55,50],[1.08,1.08,1.08],'stone',[0,0,0],0,[.86,.86,.82]);
 add('bridge_ruined',[0,9.4,8],[1.05,1.05,1.05],'stone',[0,deg(90),0],0,[.76,.77,.74]);
 for(const side of [-1,1]){add('balcony',[side*18.2,9.2,18],[.92,.92,.92],'stone',[0,side<0?deg(90):deg(-90),0]);add('balcony',[side*18.2,11.0,48],[.85,.85,.85],'stone',[0,side<0?deg(90):deg(-90),0]);}
 // boss arena is its own mesh, not a cylinder placeholder
 add('boss_arena',[0,-.75,84],[1,1,1],'stone',[0,0,0],0,[.77,.78,.75]);
 for(let i=0;i<8;i++){const a=i*Math.PI/4;add('arena_obelisk',[Math.cos(a)*15.2,-1.0,84+Math.sin(a)*15.2],[.68,.68,.68],'stone',[0,-a,0],.01,[.75,.76,.74]);}
 // arena threat silhouettes
 add('boss_custodian',[0,-.75,84],[.72,.72,.72],'stone',[0,deg(180),0],.018,[.80,.79,.74]);
 add('enemy_ash_bailiff',[-7.8,-1.20,75],[.42,.42,.42],'iron',[0,deg(165),0],.02,[.78,.70,.64]);
}

const cameraPath=[
 {p:[0,6,-77],t:[0,7,-42],f:61},{p:[15,10,-41],t:[0,7,-7],f:55},{p:[-19,12,-3],t:[0,9,26],f:52},{p:[11,8,23],t:[0,13,58],f:48},{p:[-15,11,39],t:[0,13,64],f:45},{p:[17,11,59],t:[0,8,83],f:47},{p:[11,7,18],t:[0,4,43],f:56},{p:[0,13,-12],t:[0,14,64],f:47}
];
let mouse={x:0,y:0},scrollT=0,currentScene=0,explore=false,last=performance.now();let explorePos=[0,4,-48],yaw=0,pitch=0,keys={};
let focusState=null;
let activeRiftColor=[.22,.08,.58];
const focusViews={
 unranked:{p:[11,11,51],t:[0,10.5,64],f:42},
 sacrifice:{p:[-1,6.5,25],t:[-10.2,4.8,35],f:43},
 judgement:{p:[2,7.2,26],t:[10.5,5.0,35],f:43},
 custodian:{p:[13,9,68],t:[0,7.0,84],f:42},
 bailiff:{p:[1,5,66],t:[-7.8,3.4,75],f:43},
 rift:{p:[10,8,-70],t:[0,7.5,-58],f:46}
};
function resize(){const w=Math.floor(innerWidth*DPR),h=Math.floor(innerHeight*DPR);if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;canvas.style.width=innerWidth+'px';canvas.style.height=innerHeight+'px';gl.viewport(0,0,w,h)}}
window.addEventListener('resize',resize);resize();
window.addEventListener('mousemove',e=>{mouse.x=(e.clientX/innerWidth-.5)*2;mouse.y=(e.clientY/innerHeight-.5)*2;if(explore&&document.pointerLockElement===canvas){yaw-=e.movementX*.0022;pitch=clamp(pitch-e.movementY*.0017,-1.1,1.1)}});
window.addEventListener('keydown',e=>keys[e.code]=true);window.addEventListener('keyup',e=>keys[e.code]=false);
function scrollState(){const max=document.documentElement.scrollHeight-innerHeight;scrollT=max?scrollY/max:0;const sections=[...document.querySelectorAll('.section')];let best=0,bestD=Infinity;sections.forEach((s,i)=>{const r=s.getBoundingClientRect(),d=Math.abs(r.top+innerHeight*.35);if(d<bestD){bestD=d;best=i}});if(best!==currentScene){currentScene=best;const names=['ORIGIN','INDEX','BREACH ZERO','SYSTEM','CONTRACTS','BOSSES','MOVEMENT','NULL'];document.getElementById('hudChapter').textContent=names[best]||'NULL'}document.getElementById('hudProgress').textContent=String(Math.round(scrollT*100)).padStart(2,'0')+'%'}
window.addEventListener('scroll',scrollState,{passive:true});scrollState();
function cameraForScroll(){const total=cameraPath.length-1,f=scrollT*total,i=Math.min(total-1,Math.floor(f)),u=smooth(f-i),a=cameraPath[i],b=cameraPath[i+1];const base={p:[lerp(a.p[0],b.p[0],u)+mouse.x*1.3,lerp(a.p[1],b.p[1],u)-mouse.y*.6,lerp(a.p[2],b.p[2],u)],t:[lerp(a.t[0],b.t[0],u),lerp(a.t[1],b.t[1],u),lerp(a.t[2],b.t[2],u)],f:lerp(a.f,b.f,u)};if(!focusState)return base;const q=(performance.now()-focusState.start)/focusState.duration;if(q>=1){focusState=null;document.querySelectorAll('.model-inspector button').forEach(b=>b.classList.remove('active'));return base}const blend=q<.18?smooth(q/.18):q>.82?smooth((1-q)/.18):1;const c=focusState.cam;return{p:[lerp(base.p[0],c.p[0],blend),lerp(base.p[1],c.p[1],blend),lerp(base.p[2],c.p[2],blend)],t:[lerp(base.t[0],c.t[0],blend),lerp(base.t[1],c.t[1],blend),lerp(base.t[2],c.t[2],blend)],f:lerp(base.f,c.f,blend)}}
function cameraExplore(dt){const fwd=[Math.sin(yaw)*Math.cos(pitch),Math.sin(pitch),Math.cos(yaw)*Math.cos(pitch)],right=[Math.cos(yaw),0,-Math.sin(yaw)],spd=(keys.ShiftLeft?13:6.5)*dt;if(keys.KeyW)explorePos=vadd(explorePos,vmul(fwd,spd));if(keys.KeyS)explorePos=vadd(explorePos,vmul(fwd,-spd));if(keys.KeyA)explorePos=vadd(explorePos,vmul(right,-spd));if(keys.KeyD)explorePos=vadd(explorePos,vmul(right,spd));explorePos[0]=clamp(explorePos[0],-25,25);explorePos[1]=clamp(explorePos[1],1.4,25);explorePos[2]=clamp(explorePos[2],-75,90);return{p:explorePos,t:vadd(explorePos,fwd),f:66}}

function bindMat(m){gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,m.alb);gl.uniform1i(loc.alb,0);gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,m.nor);gl.uniform1i(loc.norm,1);gl.activeTexture(gl.TEXTURE2);gl.bindTexture(gl.TEXTURE_2D,m.rough);gl.uniform1i(loc.rough,2);gl.uniform1f(loc.scale,m.scale);gl.uniform1f(loc.metal,m.metal)}
function render(now){requestAnimationFrame(render);const dt=Math.min(.04,(now-last)/1000);last=now;resize();const cam=explore?cameraExplore(dt):cameraForScroll();gl.enable(gl.DEPTH_TEST);gl.enable(gl.CULL_FACE);gl.cullFace(gl.BACK);gl.clearColor(.009,.010,.015,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);const proj=M4.perspective(deg(cam.f),canvas.width/canvas.height,.08,230),view=M4.lookAt(cam.p,cam.t);
 if(objects.length){gl.useProgram(mainProg);gl.uniformMatrix4fv(loc.view,false,view);gl.uniformMatrix4fv(loc.proj,false,proj);gl.uniform3fv(loc.cam,cam.p);gl.uniform1f(loc.time,now*.001);gl.uniform1f(loc.fog0,26);gl.uniform1f(loc.fog1,104);gl.uniform3fv(loc.rift,activeRiftColor);let current='';for(const o of objects){if(!assets[o.meshKey])continue;if(o.mat!==current){bindMat(mats[o.mat]);current=o.mat}gl.bindVertexArray(assets[o.meshKey].vao);gl.uniformMatrix4fv(loc.model,false,o.model);gl.uniform3fv(loc.tint,o.tint);gl.uniform1f(loc.em,o.em);gl.drawArrays(gl.TRIANGLES,0,assets[o.meshKey].count)}}
 // translucent dimensional sheet behind frame
 if(glowMesh){gl.disable(gl.CULL_FACE);gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE);gl.depthMask(false);gl.useProgram(glowProg);gl.uniformMatrix4fv(gloc.view,false,view);gl.uniformMatrix4fv(gloc.proj,false,proj);gl.uniform1f(gloc.time,now*.001);gl.uniform3fv(gloc.color,activeRiftColor);gl.bindVertexArray(glowMesh.vao);const model=M4.trs([0,7.6,-58.15],[0,0,0],[4.4,8.0,1]);gl.uniformMatrix4fv(gloc.model,false,model);gl.drawArrays(gl.TRIANGLES,0,glowMesh.count);gl.depthMask(true);gl.disable(gl.BLEND);}
 gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE);gl.depthMask(false);gl.useProgram(partProg);gl.uniformMatrix4fv(ploc.view,false,view);gl.uniformMatrix4fv(ploc.proj,false,proj);gl.uniform1f(ploc.time,now*.001);gl.bindVertexArray(particles.vao);gl.drawArrays(gl.POINTS,0,particles.count);gl.depthMask(true);gl.disable(gl.BLEND);
}
requestAnimationFrame(render);

function toast(msg){const el=document.getElementById('toast');el.textContent=msg;el.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>el.classList.remove('show'),2200)}
const rankValue=document.getElementById('rankValue'),rankSub=document.getElementById('rankSub'),rankConsole=document.getElementById('rankConsole'),consoleLog=document.getElementById('consoleLog');
function setRank(r){document.querySelectorAll('.rank-scale button').forEach(b=>b.classList.toggle('active',b.dataset.rank===String(r)));rankConsole.classList.remove('glitch');void rankConsole.offsetWidth;rankConsole.classList.add('glitch');const read=rankConsole.querySelector('.rank-readout');if(r==='NULL'){rankValue.textContent='NULL';rankSub.textContent='ERROR // NO EXISTE UN TECHO VÁLIDO';read.classList.add('is-null');consoleLog.innerHTML='<span>&gt; Nivel 13 detectado.</span><span>&gt; Violación del límite registrada.</span><span>&gt; Comparando jerarquías...</span><span style="color:white">&gt; ERROR: clasificación inexistente // NULL.</span>';toast('PROTOCOLO NULL ACTIVADO')}else{rankValue.textContent=r==='EX'?'RANGO EX':'RANGO '+r;rankSub.textContent=r==='EX'?'ANOMALÍA CLASIFICABLE':'TECHO DE CRECIMIENTO // REGISTRO ESTABLE';read.classList.remove('is-null')}}
document.querySelectorAll('.rank-scale button').forEach(b=>b.addEventListener('click',()=>setRank(b.dataset.rank)));document.getElementById('triggerNull').addEventListener('click',()=>setRank('NULL'));
document.querySelectorAll('.contract-card').forEach(c=>c.addEventListener('click',()=>{document.querySelectorAll('.contract-card').forEach(x=>x.classList.remove('active'));c.classList.add('active');document.getElementById('contractName').textContent=c.dataset.contract}));document.getElementById('deployContract').addEventListener('click',()=>toast('RECONSTRUCCIÓN DESPLEGADA // '+document.getElementById('contractName').textContent));
document.querySelectorAll('.boss-card button').forEach((b,i)=>b.addEventListener('click',()=>{if(i===0){focusState={cam:focusViews.custodian,start:performance.now(),duration:5600};toast('THE REDACTED CUSTODIAN // INSPECCIÓN 3D')}else if(i===1){focusState={cam:focusViews.bailiff,start:performance.now(),duration:5600};toast('ASH BAILIFF // INSPECCIÓN 3D')}else toast('ARCHIVO BLOQUEADO // INDEX REDACTED')}));
document.querySelectorAll('.model-inspector button').forEach(btn=>btn.addEventListener('click',()=>{const key=btn.dataset.focus;if(!focusViews[key])return;document.querySelectorAll('.model-inspector button').forEach(b=>b.classList.remove('active'));btn.classList.add('active');focusState={cam:focusViews[key],start:performance.now(),duration:5200};toast('INSPECTOR 3D // '+btn.textContent.trim())}));
const breachColors={catacumba:[.52,.16,.055],cisterna:[.045,.36,.38],glaciar:[.28,.58,.88],fundicion:[.78,.20,.035],santuario:[.22,.08,.58]};
document.querySelectorAll('.breach-network__grid article').forEach(card=>card.addEventListener('click',()=>{const key=card.dataset.breach;document.querySelectorAll('.breach-network__grid article').forEach(x=>x.classList.remove('active'));card.classList.add('active');activeRiftColor=breachColors[key]||breachColors.santuario;focusState={cam:focusViews.rift,start:performance.now(),duration:4800};toast('BRECHA // '+card.querySelector('i').textContent.trim())}));

document.getElementById('exploreBtn').addEventListener('click',()=>{explore=true;document.body.style.overflow='hidden';document.getElementById('exploreOverlay').classList.add('active');document.getElementById('exploreOverlay').setAttribute('aria-hidden','false');canvas.requestPointerLock?.();toast('MODO EXPLORACIÓN ACTIVO')});
function exitExplore(){explore=false;document.body.style.overflow='';document.exitPointerLock?.();document.getElementById('exploreOverlay').classList.remove('active');document.getElementById('exploreOverlay').setAttribute('aria-hidden','true')}
document.getElementById('exitExplore').addEventListener('click',exitExplore);window.addEventListener('keydown',e=>{if(e.code==='Escape'&&explore)exitExplore()});document.getElementById('wishlistBtn').addEventListener('click',()=>toast('CANAL DE DESARROLLO // PRÓXIMAMENTE'));
let audioCtx=null,master=null,audioOn=false;function startAudio(){if(!audioCtx){audioCtx=new (window.AudioContext||window.webkitAudioContext)();master=audioCtx.createGain();master.gain.value=.038;master.connect(audioCtx.destination);const d=audioCtx.createOscillator(),g=audioCtx.createGain();d.type='sine';d.frequency.value=42;g.gain.value=.65;d.connect(g).connect(master);d.start();const d2=audioCtx.createOscillator(),g2=audioCtx.createGain();d2.type='triangle';d2.frequency.value=63;g2.gain.value=.13;d2.connect(g2).connect(master);d2.start()}audioCtx.resume();master.gain.setTargetAtTime(.038,audioCtx.currentTime,.2);audioOn=true;document.getElementById('soundToggle').textContent='AUDIO ON'}function stopAudio(){if(master&&audioCtx)master.gain.setTargetAtTime(0,audioCtx.currentTime,.12);audioOn=false;document.getElementById('soundToggle').textContent='AUDIO OFF'}document.getElementById('soundToggle').addEventListener('click',()=>audioOn?stopAudio():startAudio());

loadAll().then(()=>{document.querySelector('.boot__bar span').style.width='100%';document.querySelector('.boot__status').textContent='BRECHA CERO // ONLINE';setTimeout(()=>{document.getElementById('boot').classList.add('done');document.body.classList.add('ready')},500)}).catch(err=>{console.error(err);document.querySelector('.boot__status').textContent='ERROR DE CARGA // ejecuta con servidor local';});
})();
